/*
	Author: Diego S. Cintra
	USP Number: 10094043
	Date: 06/06/2017
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/*
	Struct for schema
*/
typedef struct _schema{
	int attrSize;
	char *tableName, **names, **types;
}schema;

/*
	Find first occurrence of a delimiter and return either string until delimiter or string after delimiter
	params:
	   - str: string to be searched;
	   - delimiter: character that delimits reading;
	   - after: (1) will copy string from delimiter, (0) up until delimiter
	returns:
	   - str up to occurrence of first delimiter. If no occurrence, returns NULL
*/
char *split(char *str, char delimiter, int after)
{
	int i, j, strLen = 0;
	char *newStr = NULL;
	strLen = strlen(str);
	for(i = 0; i < strLen; i++)
	{
		if(str[i] == delimiter && !after)
		{
			str[i] = '\0';
			newStr = (char*)malloc(sizeof(char)*((i+1)+1));
			strcpy(newStr, str);
			i = strLen + 1;
		}
		else if(str[i] == delimiter && after)
		{
			newStr = (char*)malloc(sizeof(char)*((strLen-i)+1));
			i = i + 1;
			for(j = 0; i < strLen; j++)
			{
				newStr[j] = str[i];
				i = i + 1;
			}
			newStr[j] = '\0';
			i = strLen + 1;
		}
	}
	return newStr;
}

/*
	Read from a file until a given character occur
	params:
	   - file: file to be read
	   - delimiter: character that delimits reading
	returns:
	   - command read
*/
char *read(FILE *file, char delimiter)
{
	int count;
    char c;
    count = 0;
    char *line = NULL;
    do{
        c = fgetc(file);
        line = (char*)realloc(line, sizeof(char)*(count+1));
        line[count++] = c;
    }while(c != delimiter && c != EOF);
    line[count-1] = '\0';
    return line;
}

/*
	Count number of lines from a given file, rewinding at end
	param:
	   - file: file to be read
	returns:
	   - number of lines
*/
int countLines(FILE *file)
{
	int size = 0;
	char *line = NULL;
	line = read(file, '\n');
	while(line[0] > 0)
	{
		free(line);
		line = NULL;
		size = size + 1;
		line = read(file, '\n');
	}
	free(line);
	rewind(file);
	return size;
}

/*
    Deallocates matrix from heap memory
    params:
       - matrix: the matrix to be freed
       - n: matrix's size
*/
void freeMat(unsigned char **matrix, int n)
{
    int i;
    for(i = 0; i < n; i++)
    {
        free(matrix[i]);
    }
    free(matrix);
}

/* 
    Prints matrix 
    params:
       - matrix: the matrix to be printed
       - n: matrix line's length
       - m: matrix column's length
*/
void printMat(unsigned char **mat, int c, int r)
{
    int i, j;
    for(i = 0; i < r; i++)
    {
		for(j = 0; j < c; j++)
        {
        	if(j+1 == c)
        	{
        		printf("%c", mat[i][j]);	
        	}
        	else
        	{
        		printf("%c ", mat[i][j]);
        	}
        }
        printf("\n");
    }
}

/*
	Dynamically allocates matrix
	params:
	   - c: number of columns;
	   - r: number of rows
	returns:
	   - allocated matrix
*/
unsigned char **allocMat(int c, int r)
{
	int i, j;
	unsigned char **board = NULL;
	board = (unsigned char**)calloc(r, sizeof(unsigned char*));
	for(i = 0; i < r; i++)
	{
		board[i] = (unsigned char*)calloc(c, sizeof(unsigned char));
		for(j = 0; j < c; j++)
		{
			board[i][j] = '0';
		}
	}
	return board;
}

/*
	Calculate hamming distance
	params:
	   - a: first element;
	   - b: second element;
	returns:
	   - the difference between both elements
*/
int hammingDistance(int a, int b)
{
	return abs(a-b);
}

/*
	Calculate hamming distance between two images
*/
void memDist()
{
	int i, j, dist = 0, r, c;
	unsigned char **img1 = NULL, **img2 = NULL;
	char character;
	fscanf(stdin, "%d %d\n", &r, &c);
	img1 = allocMat(c, r);
	img2 = allocMat(c, r);
	for(i = 0; i < r; i++)
	{
		for(j = 0; j < c; j++)
		{
			fscanf(stdin, "%c", &character);
			img1[i][j] = character;
		}
	}
	fscanf(stdin, "\n");
	for(i = 0; i < r; i++)
	{
		for(j = 0; j < c; j++)
		{
			fscanf(stdin, "%c", &character);
			img2[i][j] = character;
		}
	}
	/* Calculate hamming distance */
	for(i = 0; i < r; i++)
	{
		for(j = 0; j < c; j++)
		{
			dist = dist + hammingDistance((int)img1[i][j], (int)img2[i][j]);
		}
	}
	/* Print dist */
	printf("dist = %d\n", dist);
	freeMat(img1, r);
	freeMat(img2, r);
}

/*
	Perform dilate operation
	params:
	   - A: matrix A;
	   - c1: matrix A number of columns;
	   - r1: matrix A number of rows;
	   - B: matrix B;
	   - c2: matrix B number of columns;
	   - r2: matrix B number of rows;
	returns:
	   - image containing dilate operation
*/
unsigned char **dilate(unsigned char **A, int c1, int r1, unsigned char **B, int c2, int r2)
{
	int i, j, k, l, xCenter, yCenter;
	unsigned char **C;
	C = allocMat(c1, r1);
	/* Get center of structuring element */
	xCenter = (r2/2);
	yCenter = (c2/2);
	/* Check every pixel of image A */
	for(i = xCenter; i < (r1-(xCenter+1)); i++)
	{
		for(j = yCenter; j < (c1-(yCenter+1)); j++)
		{
			if(A[i][j] == '1')
			{
				/* "Stamp" structuring element over C */
				for(k = 0; k < r2; k++)
				{
					for(l = 0; l < c2; l++)
					{
						if(C[i+(k-1)][j+(l-1)] != '1')
						{
							/*printf("[i+(k-1)]: %d\t[j+(l-1)]: %d\n", i+(k-1), j+(l-1));
							printf("k: %d\tl: %d\n", k, l);
							printf("C[i+(k-1)][j+(l-1)]: %c\tB[k][l]: %c\n", C[i+(k-1)][j+(l-1)], B[k][l]);*/
							C[i+(k-1)][j+(l-1)] = B[k][l];
						}
					}
				}
			}
		}
	}
	return C;
}

/*
	Count number of one pixels of image A
	params:
	   - A: matrix A containing image;
	   - c1: matrix A number of columns;
	   - r1: matrix A number of rows;
	returns:
	   - counter of number of 1 pixels
*/
int countOnePixels(unsigned char **A, int c1, int r1)
{
	int i, j, count = 0;
	for(i = 0; i < r1; i++)
	{
		for(j = 0; j < c1; j++)
		{
			if(A[i][j] == '1')
			{
				count = count + 1;
			}
		}
	}
	return count;
}

/*
	Perform erode operation
	params:
	   - A: matrix A;
	   - c1: matrix A number of columns;
	   - r1: matrix A number of rows;
	   - B: matrix B;
	   - c2: matrix B number of columns;
	   - r2: matrix B number of rows;
	returns:
	   - image containing erode operation
*/
unsigned char **erode(unsigned char **A, int c1, int r1, unsigned char **B, int c2, int r2)
{
	int i, j, k, l, xCenter, yCenter, onePixelsCount = 0, count;
	unsigned char **C;
	C = allocMat(c1, r1);
	/* Get center of structuring element */
	xCenter = (r2/2);
	yCenter = (c2/2);
	/* Get structuring element 1 pixels count */
	onePixelsCount = countOnePixels(B, c2, r2);
	/* Check every pixel of image A */
	for(i = xCenter; i < (r1-(xCenter+1)); i++)
	{
		for(j = yCenter; j < (c1-(yCenter+1)); j++)
		{
			count = 0;
			for(k = 0; k < r2; k++)
			{
				for(l = 0; l < c2; l++)
				{
					if(A[i+(k-1)][j+(l-1)] == '1' && B[k][l] == '1')
					{
						count = count + 1;
					}
				}
			}
			/* "Stamp" structuring element over C */
			if(count == onePixelsCount)
			{
				C[i][j] = '1';
			}
			else
			{
				C[i][j] = '0';
			}
		}
	}
	return C;
}

/*
	Perform open operation
	params:
	   - A: matrix A;
	   - c1: matrix A number of columns;
	   - r1: matrix A number of rows;
	   - B: matrix B;
	   - c2: matrix B number of columns;
	   - r2: matrix B number of rows;
	returns:
	   - image containing combination of erode and dilate operations
*/
unsigned char **ocrOpen(unsigned char **A, int c1, int r1, unsigned char **B, int c2, int r2)
{
	unsigned char **C = NULL;
	C = erode(A, c1, r1, B, c2, r2);
	return dilate(C, c1, r1, B, c2, r2);
}

/*
	Perform close operation
	params:
	   - A: matrix A;
	   - c1: matrix A number of columns;
	   - r1: matrix A number of rows;
	   - B: matrix B;
	   - c2: matrix B number of columns;
	   - r2: matrix B number of rows;
	returns:
	   - image containing combination of dilate and erode operations
*/
unsigned char **ocrClose(unsigned char **A, int c1, int r1, unsigned char **B, int c2, int r2)
{
	unsigned char **C = NULL;
	C = dilate(A, c1, r1, B, c2, r2);
	return erode(C, c1, r1, B, c2, r2);
}

/*
	Print according to "mem_op" command specification
	params:
	   - img1: image 1;
	   - c1: image 1 number of columns;
	   - r1: image 1 number of rows;
	   - img2: image 2;
	   - c2: image 2 number of columns;
	   - r2: image 2 number of rows;
	   - img3: image 3
*/
void printMemOp(unsigned char **img1, int c1, int r1, unsigned char **img2, int c2, int r2, unsigned char **img3)
{
	printf("im:\n");
	printMat(img1, c1, r1);
	printf("el:\n");
	printMat(img2, c2, r2);
	printf("out:\n");
	printMat(img3, c1, r1);
}

/*
	Calculate morphological operation
*/
void memOp()
{
	int i, j, c1, r1, c2, r2;
	unsigned char **img1 = NULL, **img2 = NULL, **img3 = NULL;
	char character, *operation;

	/* Read image */
	fscanf(stdin, "%d %d\n", &r1, &c1);
	img1 = allocMat(c1, r1);
	for(i = 0; i < r1; i++)
	{
		for(j = 0; j < c1; j++)
		{
			fscanf(stdin, "%c", &character);
			img1[i][j] = character;
		}
	}
	fscanf(stdin, "\n");
	/* Read structuring element */
	fscanf(stdin, "%d %d\n", &r2, &c2);
	img2 = allocMat(c2, r2);
	for(i = 0; i < r2; i++)
	{
		for(j = 0; j < c2; j++)
		{
			fscanf(stdin, "%c", &character);
			img2[i][j] = character;
		}
	}
	fscanf(stdin, "\n");
	/* Read morphological operation */
	operation = read(stdin, '\n');
	if(strcmp(operation, "dilate") == 0)
	{
		img3 = dilate(img1, c1, r1, img2, c2, r2);
	}
	else if(strcmp(operation, "erode") == 0)
	{
		img3 = erode(img1, c1, r1, img2, c2, r2);	
	}
	else if(strcmp(operation, "open") == 0)
	{
		img3 = ocrOpen(img1, c1, r1, img2, c2, r2);
	}
	else if(strcmp(operation, "close") == 0)
	{
		img3 = ocrClose(img1, c1, r1, img2, c2, r2);
	}
	/* Print output */
	printMemOp(img1, c1, r1, img2, c2, r2, img3);
}

void initSchema(schema *s, FILE *fSchema)
{
	char *esquema = NULL, *tableName = NULL;
	/* Count number of attributes; -1 given table is not an attribute */
	s->attrSize = countLines(fSchema) - 1;
	/* Allocate names and types matrices */
	s->names = (char**)malloc(sizeof(char*)*(s->attrSize));
	s->types = (char**)malloc(sizeof(char*)*(s->attrSize));
	/* Read ".schema" first line to store table name */
	esquema = read(fSchema, '\n');
	tableName = split(esquema, ' ', 1);
	s->tableName = (char*)calloc(strlen(tableName)+6, sizeof(char));
	strcat(s->tableName, tableName);
	strcat(s->tableName, ".data");
}

/*
	Read both name and type from ".schema" file
	params:
	   - file: file to be read. first line already skipped;
	   - names: matrix of strings which will contain attribute names;
	   - types: matrix of strings which will contain attribute types;
	   - attrSize: number of attributes, consequently being number of matrices rows
*/
void readNameAndType(FILE *file, char **names, char **types, int attrSize)
{
	int i;
	char *str;
	for(i = 0; i < attrSize; i++)
	{
		str = NULL;
		str = read(file, ' ');
		names[i] = NULL;
		names[i] = (char*)realloc(names[i], sizeof(char)*(strlen(str)+1));
		strcpy(names[i], str);
		free(str);
		str = NULL;
		str = read(file, '\n');
		types[i] = NULL;
		types[i] = (char*)realloc(types[i], sizeof(char)*(strlen(str)+1));
		strcpy(types[i], str);
		free(str);
	}
}

/*
	Converts a null terminating string to double
	param:
	   - number: char type number to be converted
	returns:
	   - double type number
*/
double toDouble(char *number)
{
	int i, point = 0, exponent;
	double num = 0.00000;
	for(i = 0; i < strlen(number); i++)
	{
		if(number[i] == '.')
		{
			point = 1;
			exponent = 1;
			i = i + 1;
		}
		if(point == 0)
		{
			num = ((num)*10) + (number[i]-48);
		}
		else
		{
			num = num + ((double)(number[i]-48)/(10*exponent));
			exponent = exponent * 10;
		}
	}
	return num;
}

/*
	Convert null terminating string to pointer to double
	param: 
	   - number: char type number to be converted
	returns:
	   - double * type number
*/
double *writeToDouble(char *number)
{
	double *dValue;
	dValue = (double*)malloc(sizeof(double));
	*dValue = toDouble(number);
	return dValue;
}

/*
	Converts a null terminating string to integer
	param:
	   - number: char type number to be converted
	returns:
	   - int type number
*/
int toNum(char *number)
{
	int i, num = 0;
	for(i = 0; i < strlen(number); i++)
	{
		num = ((num)*10) + (number[i]-48);
	}
	return num;
}

/*
	Convert null terminating string to pointer to integer
	param: 
	   - number: char type number to be converted
	returns:
	   - int * type number
*/
int *writeToNum(char *number)
{
	int *integer;
	integer = (int*)malloc(sizeof(int));
	*integer = toNum(number);
	return integer;
}

/*
	Get size from a string containing type
	param:
	   - type: string containing type
	returns:
	   - size from the string type, in bytes
*/
int getSize(char *type)
{
	int num;
	char *number, *number2;
	if(strcmp(type, "char") == 0)
	{
		return 1;
	}
	else if(strcmp(type, "int") == 0)
	{
		return 4;
	}
	else if(strcmp(type, "double") == 0)
	{
		return 8;
	}
	else if(strstr(type, "["))
	{
		number = NULL;
		number2 = NULL;
		number = split(type, '[', 1);
		number2 = split(number, ']', 0);
		num = toNum(number2);
		free(number);
		free(number2);
		return num;
	}
	else
	{
		return 0;
	}
}

/*
	Read training test input from stdin
	params:
	   - file: file to be written
	   - types: matrix of strings containing attribute types;
	   - attrSize: number of attributes, consequently being number of matrix rows
*/
void readTrainingTest(FILE *file, char **types, int attrSize)
{
	int i = 0, *integer, count = 0, num;
	double *doubleValue;
	char *line = NULL;
	line = read(stdin, '\n');
	while(strcmp(line, "-1") != 0)
	{
		/* (attrSize+1) because of id */
		if(count % (attrSize+2) == 0)
		{
			/* Read id first */
			count = 0;
			i = 0;
			integer = writeToNum(line);
			fwrite(integer, sizeof(int), 1, file);
			free(integer);
			free(line);
			line = NULL;
			line = read(stdin, '\n');
		}
		/* Read dist last */
		else if(count % (attrSize+1) == 0)
		{
			doubleValue = (double*)malloc(sizeof(double));
			*doubleValue = 0.00;
			fwrite(doubleValue, sizeof(double), 1, file);
			free(doubleValue);
		}
		/* Read rest of types */
		else if(strstr(types[i], "["))
		{
			// printf("line: %s\ttype: %s\n", line, type);
			num = getSize(types[i]);
			line = realloc(line, sizeof(char)*((strlen(line)+1)+num));
			fwrite(line, sizeof(char), num, file);
			i = i + 1;
			free(line);
			line = NULL;
			line = read(stdin, '\n');
		}
		else if(strcmp(types[i], "int") == 0)
		{
			integer = NULL;
			integer = writeToNum(line);
			fwrite(integer, sizeof(int), 1, file);
			free(integer);
			i = i + 1;
			free(line);
			line = NULL;
			line = read(stdin, '\n');
		}
		else if(strcmp(types[i], "double") == 0)
		{
			doubleValue = NULL;
			doubleValue = writeToDouble(line);
			fwrite(doubleValue, sizeof(double), 1, file);
			free(doubleValue);
			i = i + 1;
			free(line);
			line = NULL;
			line = read(stdin, '\n');
		}
		count = count + 1;
	}
	/* Put last entry dist */
	if(count != 0)
	{
		doubleValue = (double*)malloc(sizeof(double));
		*doubleValue = 0.00;
		fwrite(doubleValue, sizeof(double), 1, file);
		free(doubleValue);
	}
	free(line);
}

/*
	Get schema total size
	params:
	   - types: attributes types;
	   - attrSize: number of attributes, consequently being number of matrices rows
	returns:
	   - sum of sizes, in bytes
*/
int getSchemaSize(char **types, int attrSize)
{
	int i, size = 0;
	for(i = 0; i < attrSize; i++)
	{
		size = size + getSize(types[i]);
	}
	/* Summing "id" and "dist" */
	size = size + 4;
	size = size + 8;
	return size;
}

/*
	Dump ".schema" file, with additional "id" and "dist" information
	params:
	   - table: table name;
	   - attrSize: number of attributes, consequently being number of matrices rows;
	   - names: attributes names;
	   - types: attributes types
*/
void dumpSchema(char *table, int attrSize, char **names, char **types)
{
	int i, byteCount = 0;
	byteCount = getSchemaSize(types, attrSize);
	printf("table %s(%d bytes)\n", table, byteCount);
	/* attrSize+2 because of id and dist */
	for(i = 0; i < (attrSize+2); i++)
	{
		/* id */
		if(i == 0)
		{
			printf("id int(4 bytes)\n");
		}
		/* dist */
		else if(i == (attrSize+1))
		{
			printf("dist double(8 bytes)\n");
		}
		else
		{
			printf("%s %s(%d bytes)\n", names[i-1], types[i-1], getSize(types[i-1]));
		}
	}
}

int main(void)
{
	char *schemaName = NULL, *command = NULL;
	FILE *fSchema, *fData;
	schema *s;
	/* Step 1: Read .schema or "none" */
	schemaName = read(stdin, '\n');
	if(strcmp(schemaName, "none") == 0)
	{
		/* Step 2: Read command */
		command = read(stdin, '\n');
		while(strcmp(command, "exit") != 0)
		{
			/* mem_dist command */
			if(strcmp(command, "mem_dist") == 0)
			{
				memDist();
			}
			/* mem_op command */
			else if(strcmp(command, "mem_op") == 0)
			{
				memOp();
			}
			free(command);
			command = NULL;
			command = read(stdin, '\n');
		}
	}
	else
	{
		fSchema = fopen(schemaName, "r");
		if(fSchema)
		{
			s = (schema*)calloc(1, sizeof(schema));
			/* Step 2: Initialize schema struct */
			initSchema(s, fSchema);
			/* Step 3: Read names and types */
			readNameAndType(fSchema, s->names, s->types, s->attrSize);
			/* Step 4: Create ".data" file */
			fData = fopen(s->tableName, "wb");
			if(fData)
			{
				readTrainingTest(fData, s->types, s->attrSize);
			}
			else
			{
				printf("Failed to write %s file.\n", s->tableName);
			}
			fclose(fData);
		}
		else
		{
			printf("File not found.\n");
		}
		/* Step 5: Read command */
		command = read(stdin, '\n');
		while(strcmp(command, "exit") != 0)
		{
			/* dump_schema command */
			if(strcmp(command, "dump_schema") == 0)
			{
				dumpSchema(s->tableName, s->attrSize, s->names, s->types);
			}
			free(command);
			command = NULL;
			command = read(stdin, '\n');
		}
	}
	free(schemaName);
	free(command);
	return 0;
}