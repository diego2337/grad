Arquivo zip gerado em: 06/06/2017 21:04:46 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: Optical Character Recognition